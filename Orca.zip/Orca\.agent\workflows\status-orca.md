---
description: Mostra status de um projeto da Central Orca, incluindo arquivos, fases, pendencias, validacoes e proximas acoes.
---

# /status-orca

$ARGUMENTS

## Objetivo

Mostrar onde o projeto esta no fluxo da Central Orca.

## Verificar

- `projeto.md`.
- `plano-execucao.md`.
- `log-decisoes.md`.
- planilhas em `03-orcamento`.
- cotacoes em `04-cotacoes`.
- validacoes em `05-validacoes`.
- documentos em `06-documentos`.
- assinados em `07-assinados`.

## Saida

Resumo objetivo com fase atual, pendencias e proximo comando sugerido.

