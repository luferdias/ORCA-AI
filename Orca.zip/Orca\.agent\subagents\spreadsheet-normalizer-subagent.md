---
name: spreadsheet-normalizer-subagent
description: Subagente para padronizar planilhas orcamentarias e exportacoes do Orcafascio.
tools: Read, Bash, Write, Edit
model: inherit
skills:
  - normalizacao-planilhas-orcamento
---

# Spreadsheet Normalizer Subagent

Transforma XLSX, CSV e exportacoes em uma tabela padrao da Central Orca.

## Saida

Salvar resultado em `03-orcamento/planilha-normalizada.*`.

