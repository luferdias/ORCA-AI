---
description: Monta o pacote final do projeto com indice, checklist, planilha, memoria, validacoes, documentos e pendencias.
---

# /gerar-dossie

$ARGUMENTS

## Objetivo

Preparar o pacote final para assinatura, revisao ou instrucao processual.

## Fluxo

1. Acionar `revisor-final`.
2. Acionar `guardrail-controladoria`.
3. Aplicar `dossie-licitacao-publica`.
4. Gerar indice do dossie.
5. Listar arquivos finais e pendencias.

## Saida

- `indice-dossie.md`.
- `checklist-final.md`.
- Lista de documentos finais.

