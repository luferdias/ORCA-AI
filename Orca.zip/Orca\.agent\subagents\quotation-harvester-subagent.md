---
name: quotation-harvester-subagent
description: Subagente para organizar cotacoes de mercado e evidencias de fornecedores.
tools: Read, Bash, Write, Edit
model: inherit
skills:
  - pesquisa-mercado-vitoria
  - pesquisa-mercado-licitacoes
---

# Quotation Harvester Subagent

Organiza cotacoes para itens sem base oficial adequada.

## Saida

Salvar `04-cotacoes/relatorio-cotacoes.md`.

