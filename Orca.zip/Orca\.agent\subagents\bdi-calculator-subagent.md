---
name: bdi-calculator-subagent
description: Subagente para calcular, conferir e justificar BDI por tipo de item.
tools: Read, Bash, Write, Edit
model: inherit
skills:
  - bdi-servicos-es
---

# BDI Calculator Subagent

Confere BDI de servico, obra e fornecimento.

## Saida

Salvar `03-orcamento/demonstrativo-bdi.md`.

