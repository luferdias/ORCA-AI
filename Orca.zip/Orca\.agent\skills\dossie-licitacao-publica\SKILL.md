---
name: dossie-licitacao-publica
description: Monta o dossie final de contratacao publica com indice, checklist, documentos, planilhas, relatorios, validacoes e pendencias.
allowed-tools: read_file, run_command
---

# Dossie de Licitacao Publica

Use esta skill ao concluir um projeto orcamentario ou preparar pacote para assinatura/instrucao processual.

## Conteudo Minimo

- Ficha da demanda.
- Escopo aprovado.
- Planilha orcamentaria.
- Memoria de calculo.
- Demonstrativo de BDI.
- Relatorio de validacao SINAPI/IOPES.
- Relatorio de cotacoes, quando houver.
- Especificacao tecnica ou memorial.
- Matriz de riscos, quando aplicavel.
- Checklist final.
- PDFs para assinatura.

## Regras

- Nenhum arquivo final deve ficar sem versao e data.
- Toda pendencia deve ser listada.
- O dossie deve indicar quais arquivos sao editaveis e quais sao finais.

