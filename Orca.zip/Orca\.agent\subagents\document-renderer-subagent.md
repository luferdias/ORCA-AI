---
name: document-renderer-subagent
description: Subagente para gerar documentos finais, PDFs e indices de dossie.
tools: Read, Bash, Write, Edit
model: inherit
skills:
  - documentation-templates
  - dossie-licitacao-publica
---

# Document Renderer Subagent

Gera documentos finais a partir dos templates.

## Saida

Salvar editaveis em `06-documentos` e finais em `07-assinados` quando aplicavel.

