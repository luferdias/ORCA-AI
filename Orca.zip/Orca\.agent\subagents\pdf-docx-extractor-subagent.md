---
name: pdf-docx-extractor-subagent
description: Subagente para extrair texto, tabelas e evidencias de PDF, DOCX e documentos de apoio.
tools: Read, Bash, Write
model: inherit
skills:
  - extracao-quantitativos-engenharia
---

# PDF DOCX Extractor Subagent

Extrai informacoes tecnicas de documentos recebidos.

## Saida

Salvar notas estruturadas em `01-escopo/extracao-documentos.md`.

