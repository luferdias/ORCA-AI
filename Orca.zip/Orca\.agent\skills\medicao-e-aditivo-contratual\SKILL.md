---
name: medicao-e-aditivo-contratual
description: Apoia medicao contratual, analise de saldo, reajuste, reequilibrio, acrescimos, supressoes e aditivos em obras e servicos de engenharia.
allowed-tools: read_file, run_command
---

# Medicao e Aditivo Contratual

Use esta skill quando o trabalho envolver contrato em execucao, boletim de medicao, termo aditivo ou reequilibrio economico-financeiro.

## Procedimento

1. Identificar contrato, objeto e saldo.
2. Comparar planilha contratada, executado e solicitado.
3. Verificar criterios de medicao.
4. Separar acrescimos, supressoes e itens novos.
5. Avaliar necessidade de composicao propria.
6. Produzir nota tecnica com recomendacao.

## Regras

- Nao aceitar medicao sem evidencia de execucao.
- Item novo deve seguir o mesmo fluxo de fonte e validacao.
- Reequilibrio exige fato motivador, memoria e evidencia.

