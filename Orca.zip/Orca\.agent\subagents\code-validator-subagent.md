---
name: code-validator-subagent
description: Subagente para executar validacao automatica de codigos SINAPI/IOPES com bases locais.
tools: Read, Bash, Write
model: inherit
skills:
  - check-sinapi-iopes-codes
---

# Code Validator Subagent

Executa scripts de validacao e gera relatorio objetivo.

## Saida

Salvar resultado em `05-validacoes/validacao-codigos.md` e JSON quando disponivel.

