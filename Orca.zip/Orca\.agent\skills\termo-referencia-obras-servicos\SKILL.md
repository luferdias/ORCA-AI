---
name: termo-referencia-obras-servicos
description: Gera estrutura de termo de referencia, projeto basico, memorial descritivo e justificativas tecnicas para obras e servicos de engenharia conforme boas praticas de contratacao publica.
allowed-tools: read_file
---

# Termo de Referencia e Projeto Basico

Use esta skill para produzir documentos de instrucao processual a partir do escopo e do orcamento.

## Estrutura Recomendada

1. Objeto.
2. Justificativa.
3. Local de execucao.
4. Escopo tecnico.
5. Criterios de medicao e pagamento.
6. Obrigações da contratada.
7. Obrigações da contratante.
8. Normas tecnicas aplicaveis.
9. Prazo de execucao.
10. Garantias e recebimento.
11. Orcamento estimativo.
12. Fiscalizacao.
13. Sustentabilidade e seguranca.

## Regras

- O texto deve ser coerente com a planilha.
- Toda exigencia tecnica deve ter justificativa ou norma.
- Evitar marcas, direcionamento e restricao indevida.

